def hello(): return 'world'
